import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import logo from "@/assets/brand/ilkoku-logo-desktop-retina.png";
import "./landing.css";

export const metadata: Metadata = {
  title: "İlkOku | Yaz, geliştir, yayımlan",
  description:
    "Yazarları, okuyucuları, editörleri ve yayınevlerini aynı platformda buluşturan dijital edebiyat ekosistemi.",
};

const roles = [
  {
    key: "writer",
    title: "Yazar",
    description: "Eserini güvenle oluştur, geliştir ve yayın yolculuğunu yönet.",
    icon: "✦",
    tone: "writer",
    cta: "Yazmaya Başla",
  },
  {
    key: "reader",
    title: "Okuyucu",
    description: "Yeni metinler keşfet, okuduklarını değerlendir ve favorilerini oluştur.",
    icon: "▤",
    tone: "reader",
    cta: "Keşfetmeye Başla",
  },
  {
    key: "editor",
    title: "Editör",
    description: "Yazarlara yapıcı geri bildirim sun, eserlerin gelişimine katkı sağla.",
    icon: "✓",
    tone: "editor",
    cta: "Editör Olarak Katıl",
  },
  {
    key: "publisher",
    title: "Yayınevi",
    description: "Yeni yazarları ve yayın potansiyeli taşıyan eserleri tek yerde keşfet.",
    icon: "⌂",
    tone: "publisher",
    cta: "Eserleri İncele",
  },
] as const;

const benefits = [
  ["◇", "Güvenli eser yönetimi", "Taslakların ve eserlerin rol bazlı erişimle korunur."],
  ["◌", "Yapıcı geri bildirim", "Eserini geliştirmene yardımcı olacak düzenli değerlendirmeler al."],
  ["▥", "Yayınevleriyle bağlantı", "İzin verdiğin eserleri doğru yayın profesyonellerine ulaştır."],
  ["↗", "Gelişim takibi", "Yazım sürecini, bölümlerini ve ilerlemeni tek alanda yönet."],
  ["◎", "Edebiyat topluluğu", "Yazarlar, okuyucular ve editörlerle aynı ekosistemde buluş."],
  ["ϟ", "Tüm cihazlarda", "Masaüstü, tablet ve telefonda kesintisiz kullan."],
] as const;

const steps = [
  ["01", "Rolünü seç", "İlkOku’ya yazar, okuyucu, editör veya yayınevi olarak katıl."],
  ["02", "Hesabını oluştur", "Kısa kayıt sürecini tamamla ve çalışma alanını hazırla."],
  ["03", "Üret veya keşfet", "Eserini oluştur, yeni metinler keşfet ya da değerlendirme yap."],
  ["04", "Yolculuğunu ilerlet", "Geri bildirim al, gelişimini takip et ve doğru kişilerle buluş."],
] as const;

const faqs = [
  ["İlkOku nedir?", "Yazarları, okuyucuları, editörleri ve yayınevlerini aynı dijital ekosistemde buluşturan bir edebiyat platformudur."],
  ["Eserimin hakları bana mı ait?", "Evet. Eserinizin fikrî ve mali hakları size aittir. İlkOku yalnızca eserinizi oluşturmanız ve yönetmeniz için araçlar sağlar."],
  ["Yayınevleri bütün eserlerimi görebilir mi?", "Hayır. Yalnızca paylaşım izni verdiğiniz veya ilgili sürece gönderdiğiniz eserler yetkili kullanıcılar tarafından görüntülenebilir."],
  ["Temel kullanım ücretli mi?", "Erken erişim döneminde temel hesap oluşturma ve ana yazarlık araçları ücretsiz sunulur."],
] as const;

export default function HomePage() {
  return (
    <main className="landing-page">
      <header className="landing-header">
        <div className="landing-container landing-header__inner">
          <Link className="landing-logo" href="/" aria-label="İlkOku ana sayfa">
            <Image src={logo} alt="İlkOku" priority />
          </Link>

          <nav className="landing-nav" aria-label="Ana menü">
            <a href="#hakkimizda">Hakkımızda</a>
            <a href="#nasil-calisir">Nasıl Çalışır?</a>
            <a href="#roller">Kimler İçin?</a>
            <Link href="/yayinevleri">Yayınevleri</Link>
            <a href="#sss">SSS</a>
          </nav>

          <div className="landing-header__actions">
            <Link className="landing-button landing-button--ghost" href="/giris">
              Giriş Yap
            </Link>
            <Link className="landing-button landing-button--primary" href="/kayit">
              Ücretsiz Başla
            </Link>
          </div>
        </div>
      </header>

      <section className="landing-hero" id="hakkimizda">
        <div className="landing-container landing-hero__grid">
          <div className="landing-hero__content">
            <span className="landing-kicker">Dijital edebiyat ekosistemi</span>
            <h1>
              Yazmaya başla.
              <br />
              Geliştir. <span>Yayınla.</span>
            </h1>
            <p>
              İlkOku; yazarları, okuyucuları, editörleri ve yayınevlerini güvenli,
              sade ve üretim odaklı tek bir platformda buluşturur.
            </p>
            <div className="landing-hero__actions">
              <Link className="landing-button landing-button--primary landing-button--large" href="/kayit?rol=writer">
                Ücretsiz Hesap Oluştur <span aria-hidden="true">→</span>
              </Link>
              <a className="landing-button landing-button--soft landing-button--large" href="#nasil-calisir">
                Nasıl Çalışır?
              </a>
            </div>
            <div className="landing-hero__trust" aria-label="Platform avantajları">
              <span>✓ Güvenli eser saklama</span>
              <span>✓ Rol bazlı erişim</span>
              <span>✓ Erken erişimde ücretsiz</span>
            </div>
          </div>

          <div className="landing-hero__visual" aria-label="Dijital yazarlık çalışma alanı illüstrasyonu">
            <div className="landing-visual__glow" />
            <div className="landing-visual__card landing-visual__card--editor">
              <span>EDİTÖR NOTU</span>
              <strong>Güçlü bir açılış</strong>
              <p>Karakterin motivasyonu ilk bölümde netleşiyor.</p>
            </div>
            <div className="landing-visual__desk">
              <div className="landing-visual__screen">
                <div className="landing-visual__screenbar"><i /><i /><i /></div>
                <small>Bölüm 01</small>
                <h2>Kayıp Şehrin Sesi</h2>
                <div className="landing-visual__line landing-visual__line--wide" />
                <div className="landing-visual__line" />
                <div className="landing-visual__line landing-visual__line--mid" />
                <div className="landing-visual__cursor" />
              </div>
              <div className="landing-visual__book"><span>İLK</span><strong>OKU</strong></div>
              <div className="landing-visual__cup">☕</div>
            </div>
            <div className="landing-visual__card landing-visual__card--progress">
              <span>BU HAFTA</span>
              <strong>4.280 kelime</strong>
              <div><i /></div>
            </div>
          </div>
        </div>
      </section>

      <section className="landing-trustbar" aria-label="Güven özellikleri">
        <div className="landing-container landing-trustbar__grid">
          <div><strong>SSL</strong><span>Güvenli bağlantı</span></div>
          <div><strong>Bulut</strong><span>Senkronize çalışma</span></div>
          <div><strong>Kontrol</strong><span>Rol bazlı erişim</span></div>
          <div><strong>Gizlilik</strong><span>Eser sahibinde</span></div>
        </div>
      </section>

      <section className="landing-section landing-section--roles" id="roller">
        <div className="landing-container">
          <div className="landing-section-heading">
            <span className="landing-eyebrow">KİMLER İÇİN?</span>
            <h2>Edebiyatın her rolü için tek platform</h2>
            <p>İhtiyacına uygun çalışma alanını seç ve kendi yolculuğuna başla.</p>
          </div>

          <div className="landing-role-grid">
            {roles.map((role) => (
              <Link className={`landing-role landing-role--${role.tone}`} href={`/kayit?rol=${role.key}`} key={role.key}>
                <span className="landing-role__icon" aria-hidden="true">{role.icon}</span>
                <h3>{role.title}</h3>
                <p>{role.description}</p>
                <strong>{role.cta} <span aria-hidden="true">→</span></strong>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="landing-section landing-section--steps" id="nasil-calisir">
        <div className="landing-container">
          <div className="landing-section-heading">
            <span className="landing-eyebrow">NASIL ÇALIŞIR?</span>
            <h2>Dört adımda İlkOku</h2>
            <p>Karmaşık süreçler yerine sade, anlaşılır ve odaklı bir deneyim.</p>
          </div>
          <div className="landing-steps">
            {steps.map(([number, title, description]) => (
              <article key={number}>
                <span className="landing-step__number">{number}</span>
                <h3>{title}</h3>
                <p>{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="landing-section landing-section--benefits">
        <div className="landing-container">
          <div className="landing-section-heading">
            <span className="landing-eyebrow">NEDEN İLKOKU?</span>
            <h2>Yazarlık yolculuğunun ihtiyaç duyduğu altyapı</h2>
            <p>Sahte istatistikler değil; bugün gerçekten sunduğumuz faydalar.</p>
          </div>

          <div className="landing-benefits">
            {benefits.map(([icon, title, description]) => (
              <article key={title}>
                <span aria-hidden="true">{icon}</span>
                <h3>{title}</h3>
                <p>{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="landing-section landing-section--faq" id="sss">
        <div className="landing-container landing-faq">
          <div className="landing-faq__intro">
            <span className="landing-eyebrow">SIK SORULAN SORULAR</span>
            <h2>Merak edilenler</h2>
            <p>İlkOku’nun kullanımına ve eser güvenliğine dair temel cevaplar.</p>
          </div>
          <div className="landing-faq__items">
            {faqs.map(([question, answer]) => (
              <details key={question}>
                <summary>{question}<span aria-hidden="true">+</span></summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="landing-cta">
        <div className="landing-container">
          <div className="landing-cta__inner">
            <div>
              <span className="landing-eyebrow landing-eyebrow--light">İLK ADIMINI AT</span>
              <h2>İlk eserini bugün oluşturmaya başla.</h2>
              <p>Hesabını ücretsiz oluştur, yazını güvenle sakla ve gelişimini tek yerden takip et.</p>
            </div>
            <Link className="landing-button landing-button--white landing-button--large" href="/kayit?rol=writer">
              Ücretsiz Hesap Oluştur <span aria-hidden="true">→</span>
            </Link>
          </div>
        </div>
      </section>

      <footer className="landing-footer" id="iletisim">
        <div className="landing-container landing-footer__grid">
          <div className="landing-footer__brand">
            <Link className="landing-logo landing-logo--footer" href="/">
              <Image src={logo} alt="İlkOku" />
            </Link>
            <p>Yaz, geliştir ve yayın yolculuğunu tek platformda yönet.</p>
            <a href="mailto:destek@ilkoku.com">destek@ilkoku.com</a>
          </div>
          <div>
            <h3>Platform</h3>
            <a href="#hakkimizda">Hakkımızda</a>
            <a href="#nasil-calisir">Nasıl Çalışır?</a>
            <Link href="/editorler">Editörler</Link>
            <Link href="/yayinevleri">Yayınevleri</Link>
          </div>
          <div>
            <h3>Hesap</h3>
            <Link href="/giris">Giriş Yap</Link>
            <Link href="/kayit">Kayıt Ol</Link>
            <Link href="/sifremi-unuttum">Şifremi Unuttum</Link>
          </div>
          <div>
            <h3>Destek</h3>
            <a href="#sss">Sık Sorulan Sorular</a>
            <a href="mailto:destek@ilkoku.com">Bize Ulaşın</a>
            <span>Gizlilik Politikası</span>
            <span>Kullanım Şartları</span>
          </div>
        </div>
        <div className="landing-container landing-footer__bottom">
          <p>© 2026 İlkOku. Tüm hakları saklıdır.</p>
          <span>Türkiye’de edebiyat için geliştirildi.</span>
        </div>
      </footer>
    </main>
  );
}
